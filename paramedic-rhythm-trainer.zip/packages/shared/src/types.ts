/**
 * Shared type definitions used across multiple packages.  These types are
 * intentionally minimal at this stage; see the project plan for a full
 * specification of the rhythm data model.
 */

/** Names of the standard 12 leads used in a diagnostic ECG. */
export type LeadName =
  | 'I'
  | 'II'
  | 'III'
  | 'aVR'
  | 'aVL'
  | 'aVF'
  | 'V1'
  | 'V2'
  | 'V3'
  | 'V4'
  | 'V5'
  | 'V6';

/** Mode selection for a rhythm generator. */
export type RhythmMode = 'parametric' | 'timeline';

/** Minimal shape of the quiz answer set for each rhythm. */
export interface RhythmQuiz {
  rate: string;
  regularity: string;
  p: string;
  pr: string;
  qrs: string;
  name: string;
  action: string;
}

/**
 * Placeholder for the rhythm specification object.  A complete definition
 * appears in the design documentation; this interface captures only the
 * required identity and quiz fields for now.
 */
export interface RhythmSpec {
  /** Schema version identifier; required for future migrations. */
  schema: string;
  /** Unique identifier for this rhythm. */
  id: string;
  /** Displayable title. */
  title: string;
  /** Which generator mode is used to synthesise the waveform. */
  mode: RhythmMode;
  /** Quiz answers for this rhythm. */
  quiz: RhythmQuiz;
}

/** Samples returned from the ECG engine. */
export interface Samples {
  /** Starting time in seconds since the beginning of the case. */
  tStart: number;
  /** Time delta between consecutive samples. */
  dt: number;
  /** Samples keyed by lead name. */
  data: Record<LeadName, Float32Array>;
}