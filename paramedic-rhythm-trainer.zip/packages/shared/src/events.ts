import mitt from 'mitt';

/**
 * Define the shape of events emitted across package boundaries.  Each channel
 * carries a particular payload type.  Add additional events as the project
 * grows.
 */
export type Events = {
  'ENGINE/SAMPLES': SamplesEvent;
  'ACTION/APPLIED': ActionEvent;
  'GAME/STEP': GameStepEvent;
  'TIMER/TICK': TimerTickEvent;
};

/** Event payload for updated samples from the ECG engine. */
export interface SamplesEvent {
  samples: import('./types').Samples;
}

/** Event payload for an applied intervention action. */
export interface ActionEvent {
  action: any; // To be replaced with proper Action type
}

/** Event payload for question step changes. */
export interface GameStepEvent {
  step: number;
}

/** Event payload for timer ticks. */
export interface TimerTickEvent {
  remaining: number;
}

/**
 * Global event bus instance.  Every package that needs to communicate
 * externally should import and use this emitter.  The emitter is strongly
 * typed via the Events interface above.
 */
export const bus = mitt<Events>();