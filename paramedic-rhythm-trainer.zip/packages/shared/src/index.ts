// Re‑export shared types, event definitions and validation schemas.  These
// exports are intentionally kept minimal to decouple the shared layer from
// the consuming packages.

export * from './types';
export * from './events';
// Note: schema definitions will live in a separate module once implemented.